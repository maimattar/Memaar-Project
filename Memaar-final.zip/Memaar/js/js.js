/*** *** ***

  Fixed Menu

*** *** ***/
$(document).ready(function() {
    $(function(){
        var Fixed=$(".fixed-top");
        // on Window Scrolling
         $(window).scroll(function(){
             if($(this).scrollTop()>=200){
                 Fixed.addClass("fixedBg");
              }
             else{
                 Fixed.removeClass("fixedBg");
             }
         });
    });
});


/*** *** ***

   Magnific Popup

*** *** ***/
$('.img-magnific-popup').magnificPopup({
  type:'image',
  gallery:{
    enabled:true
  },
});
$('.img-popup').magnificPopup({
  type:'image',
  gallery:{
    enabled:true
  },
});
// Vedio
$('.btn-white').magnificPopup({
    disableOn: 700,
    type: 'iframe',
    mainClass: 'mfp-fade',
    removalDelay: 160,
    preloader: false,
    fixedContentPos: false,
    iframe: {
        patterns: {
            youtube: {
                index: 'youtube.com/',
                id: 'v=',

            }
        }
    }
});


/*** *** ***

   Google Map

*** *** ***/
function CoordMapType(tileSize) {
  this.tileSize = tileSize;
}
function initMap() {
  var uluru = {lat: 41.850, lng: -87.650};
  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 15,
    center: uluru
  });
}


/*** *** ***

   Swiper

*** *** ***/
var swiper = new Swiper('.OurProjects', {
  slidesPerView: 3,
  spaceBetween: 50,
  grabCursor: true,
  loop: true,
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
  breakpoints: {
    579: {
      slidesPerView: 1,
      spaceBetween: 50,
    },
    991: {
      slidesPerView: 2,
      spaceBetween: 50,
    },
  }
});


var swiper = new Swiper('.Partners', {
  slidesPerView: 6,
  spaceBetween: 20,
  grabCursor: true,
  loop: true,
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
  breakpoints: {
    579: {
      slidesPerView: 2,
      spaceBetween: 50,
    },
    767: {
      slidesPerView: 3,
      spaceBetween: 30,
    },
    991: {
      slidesPerView: 4,
      spaceBetween: 20,
    },
  }
});

var swiper = new Swiper('.Testmonials', {
  slidesPerView: 1,
  spaceBetween:50,
  grabCursor: true,
  loop: true,
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
});
